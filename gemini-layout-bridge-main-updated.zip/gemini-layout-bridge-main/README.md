# gemini-layout-bridge
Converting Gemini Pro generated layouts to WP pages/posts 
