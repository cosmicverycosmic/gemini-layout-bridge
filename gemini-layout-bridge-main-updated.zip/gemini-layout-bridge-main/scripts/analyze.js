const fs = require('fs');
const path = require('path');
const AdmZip = require('adm-zip');
const args = require('minimist')(process.argv.slice(2));

/**
 * GLB Architect (local parser)
 *
 * Goal: produce a layout.json that the WP plugin can render deterministically:
 *   {
 *     "head_html": "<style>...</style><script>...</script>",
 *     "sections": [ { "id": "section-1", "html": "..." }, ... ]
 *   }
 *
 * This intentionally avoids LLM classification/mapping. Every section becomes
 * a Divi Code module (or classic raw HTML). The WP plugin can still optionally
 * install a sandbox plugin when provided.
 */

const SOURCE_ZIP = 'source.zip';
const CONTEXT_FILE = 'context.json';
const OUTPUT_LAYOUT = 'layout.json';
const OUTPUT_PLUGIN = 'plugin.php';

function log(...m) {
  console.log('[GLB Architect]', ...m);
}

function safeRead(fp) {
  try {
    return fs.readFileSync(fp, 'utf8');
  } catch (_) {
    return '';
  }
}

function walkFiles(dir) {
  const out = [];
  (function walk(d) {
    if (!fs.existsSync(d)) return;
    for (const ent of fs.readdirSync(d, { withFileTypes: true })) {
      const full = path.join(d, ent.name);
      if (ent.isDirectory()) {
        if (['node_modules', '.git'].includes(ent.name)) continue;
        walk(full);
      } else {
        out.push(full);
      }
    }
  })(dir);
  return out;
}

function pickEntryHtml(rootDir) {
  // Prefer build outputs commonly produced by "download zip" exports.
  const candidates = [
    'index.html',
    path.join('dist', 'index.html'),
    path.join('build', 'index.html'),
    path.join('public', 'index.html'),
    path.join('src', 'index.html'),
  ];

  for (const rel of candidates) {
    const fp = path.join(rootDir, rel);
    if (fs.existsSync(fp)) return fp;
  }

  // Fallback: first index.html anywhere.
  const any = walkFiles(rootDir).find((f) => /(?:^|\/)index\.html$/i.test(f));
  return any || null;
}

function normalizeAssetPath(hrefOrSrc) {
  if (!hrefOrSrc) return '';
  const s = String(hrefOrSrc).trim();
  if (!s) return '';
  if (s.startsWith('http://') || s.startsWith('https://') || s.startsWith('//')) return s;
  // Remove leading / so we can resolve against extracted root.
  return s.replace(/^\//, '');
}

function inlineLinkedAssets(indexHtml, indexDir, extractedRoot) {
  // Inline <link rel="stylesheet" href="..."> and <script src="...">.
  // We keep any inline <style> and <script> from the original index.

  const headParts = [];

  // Keep inline <style> blocks
  const styleRe = /<style[^>]*>[\s\S]*?<\/style>/gi;
  let m;
  while ((m = styleRe.exec(indexHtml)) !== null) headParts.push(m[0]);

  // Inline linked stylesheets
  const linkRe = /<link[^>]+rel=["']stylesheet["'][^>]*>/gi;
  const hrefRe = /href=["']([^"']+)["']/i;
  const cssChunks = [];
  while ((m = linkRe.exec(indexHtml)) !== null) {
    const tag = m[0];
    const hm = tag.match(hrefRe);
    if (!hm) continue;
    const rel = normalizeAssetPath(hm[1]);
    if (!rel || rel.startsWith('http')) continue;
    const fromIndexDir = path.join(indexDir, rel);
    const fromRoot = path.join(extractedRoot, rel);
    const css = safeRead(fs.existsSync(fromIndexDir) ? fromIndexDir : fromRoot);
    if (css.trim()) cssChunks.push(css);
  }
  if (cssChunks.length) {
    headParts.push('<style>\n' + cssChunks.join('\n\n') + '\n</style>');
  }

  // Keep inline <script> blocks
  const scriptInlineRe = /<script(?![^>]*\bsrc=)[^>]*>[\s\S]*?<\/script>/gi;
  while ((m = scriptInlineRe.exec(indexHtml)) !== null) headParts.push(m[0]);

  // Inline linked scripts
  const scriptSrcRe = /<script[^>]+src=["']([^"']+)["'][^>]*><\/script>/gi;
  const jsChunks = [];
  while ((m = scriptSrcRe.exec(indexHtml)) !== null) {
    const rel = normalizeAssetPath(m[1]);
    if (!rel || rel.startsWith('http')) continue;
    const fromIndexDir = path.join(indexDir, rel);
    const fromRoot = path.join(extractedRoot, rel);
    const js = safeRead(fs.existsSync(fromIndexDir) ? fromIndexDir : fromRoot);
    if (js.trim()) jsChunks.push(js);
  }
  if (jsChunks.length) {
    headParts.push('<script>\n' + jsChunks.join('\n\n;\n\n') + '\n</script>');
  }

  return headParts.join('\n');
}

function extractBodyInnerHtml(indexHtml) {
  const bodyMatch = indexHtml.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
  if (bodyMatch && bodyMatch[1]) return bodyMatch[1].trim();
  // If no body tag, use the whole document.
  return indexHtml.trim();
}

function splitIntoSections(html) {
  const sections = [];
  const re = /<(section|header|main|footer)[^>]*>[\s\S]*?<\/\1>/gi;
  let m;
  while ((m = re.exec(html)) !== null) sections.push(m[0]);
  if (!sections.length) sections.push(html);
  return sections;
}

function wrapSectionHtml(raw, idx) {
  const sectionId = `section-${idx + 1}`;
  return {
    id: sectionId,
    class: `glb-section glb-section-${sectionId}`,
    html: raw,
    // type/builder fields are optional; renderer ignores them in the simplified path.
    type: 'code',
    builder: { divi: { module_type: 'code', params: {} } },
  };
}

async function run() {
  try {
    log('----------------------------------------');
    log('GLB Architect (local parser)');
    log(`Target: ${args.builder || 'divi'}`);
    log('----------------------------------------');

    if (!fs.existsSync(SOURCE_ZIP)) throw new Error('source.zip missing');
    if (!fs.existsSync(CONTEXT_FILE)) {
      // Context is optional for this simplified pipeline.
      log('context.json not found (ok).');
    }

    // 1) Extract
    const zip = new AdmZip(SOURCE_ZIP);
    const outDir = 'extracted_source';
    zip.extractAllTo(outDir, true);

    // 2) Find entry HTML
    const entry = pickEntryHtml(outDir);
    if (!entry) throw new Error('Could not locate index.html in source.zip');
    const indexHtml = safeRead(entry);
    if (!indexHtml.trim()) throw new Error('index.html was empty');

    const indexDir = path.dirname(entry);

    // 3) Global head assets: inline linked CSS/JS (local only) + keep inline head blocks.
    const head_html = inlineLinkedAssets(indexHtml, indexDir, outDir);

    // 4) Split body into presentational sections
    const bodyInner = extractBodyInnerHtml(indexHtml);
    const rawSections = splitIntoSections(bodyInner);
    const sections = rawSections.map((s, i) => wrapSectionHtml(s, i));

    const layout = {
      head_html,
      body_class: '',
      sections,
    };

    fs.writeFileSync(OUTPUT_LAYOUT, JSON.stringify(layout, null, 2));
    log(`Wrote ${OUTPUT_LAYOUT}: ${sections.length} section(s).`);

    // Always emit a plugin.php (even if empty) so the workflow artifact upload is stable.
    if (!fs.existsSync(OUTPUT_PLUGIN)) {
      fs.writeFileSync(
        OUTPUT_PLUGIN,
        "<?php\n/**\n * GLB Sandbox Plugin (optional)\n *\n * This file is intentionally empty for the simplified parser path.\n * If the project requires custom WP-side runtime behavior, the worker can emit\n * real PHP here and GLB will install/activate it upon approval.\n */\n"
      );
    }
  } catch (e) {
    console.error('ERROR:', e.message);
    // Emit a minimal error layout so WP still shows something.
    const layout = {
      head_html: '',
      body_class: '',
      sections: [
        {
          id: 'error',
          class: 'glb-section glb-section-error',
          html: `<div style="color:red">Build Error: ${String(e.message).replace(/</g, '&lt;')}</div>`,
          type: 'code',
          builder: { divi: { module_type: 'code', params: {} } },
        },
      ],
    };
    fs.writeFileSync(OUTPUT_LAYOUT, JSON.stringify(layout, null, 2));
    if (!fs.existsSync(OUTPUT_PLUGIN)) {
      fs.writeFileSync(OUTPUT_PLUGIN, "<?php\n// GLB sandbox plugin empty (error path)\n");
    }
    process.exit(0);
  }
}

run();
